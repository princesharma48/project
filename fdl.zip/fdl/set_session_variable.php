<?php 
session_start();
if(isset($_SESSION["aa"])) {
    header("location:modal.php");
}


?>