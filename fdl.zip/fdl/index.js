
$(document).ready(function () {
    $('#dataTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf', 'print'
        ]
    });
});

// var preloader=document.getElementById("myModal");
// var img = document.getElementById("picture");
// var modalImg = document.getElementById("fullPicture");
// function myFunction(){
//     preloader.style.display="none";
    
// };

// $(document).ready(function(){
//     setTimeout(function(){
//         $('#myModal').css('display','block');
//     },3000);
//     img.src=this.src;
    
// });


