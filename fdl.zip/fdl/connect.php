<?php 
define('DB_SERVER','localhost');
define('DB_USERNAME','harry');
define('DB_PASSWORD','MyStrongPassword1234$');
define('DB_NAME','US');

$con=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_NAME);

if($con==false){
    dir ("ERROR:Cannot connect to the server");
}

else{
//  echo "Connection is successful with the database";
}
?>